--
-- PostgreSQL database dump
--

\restrict NLo8gEBOv4kg8xLJOQPUEQXy0WNswlKssaOqkNeqsgGOEat7ZbG7ruQDmqQqRvf

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_blobs (id, key, filename, content_type, metadata, service_name, byte_size, checksum, created_at) FROM stdin;
2	nbcjadgtz4gcbdn9frb5h5wedcuu	Mercedes.jpg	image/jpeg	{"identified":true,"analyzed":true}	local	179008	OeObwisWsP3cJqnXfm82DA==	2026-01-10 18:14:59.466708
4	8k69dd7jv77jke3kukoh5pjsgoin	Polo.webp	image/webp	{"identified":true,"analyzed":true}	local	323400	x3JzY85MJ7ym/fSs6hyp0A==	2026-01-15 12:45:14.010566
8	gqpx0nb92ofsjlhh2kort97vl8gy	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjcifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	134132	yjEO+p1TH1VB/C2K/gJ/tQ==	2026-01-15 12:50:45.420935
7	344e67sr8ygr95sjjcz0ycm3sea6	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjgifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	248952	ks18XOQsAHrDmiW1JZKFeQ==	2026-01-15 12:50:45.416202
6	k70sy9fvlgdsqwf3fntux36v0ecd	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjkifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	203952	gUFOecw+zmq+ch7V4ccW9w==	2026-01-15 12:50:45.410256
9	rsikmngny0ij3pwi3kmy8gel5a49	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjYifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	136922	Ofy/xrgOSxRY0mz3XJKJrQ==	2026-01-15 12:50:45.425278
10	qrq8syhjgup3v0csxh1ra8fszd5e	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjUifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	252876	KdKkEAZLBsNRxHoY3fX1oQ==	2026-01-15 12:50:45.429985
12	nmd1kzkk80gowdzmj7dsb0bpfklm	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjMifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	232610	MPtRvsFQTsZiVX6wXFFV0A==	2026-01-15 12:50:45.439442
11	6jdyoqkoie43v1uoeena61q5bbd2	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJ0b0Zvcm1hdCI6IndlYnAiLCJyZXNpemUiOnsiZml0IjoiaW5zaWRlIiwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMH19LCJrZXkiOiJwaG90b18zNzQ2Mzg0MjQifQ==.webp	image/webp	{"identified":true,"analyzed":true}	local	246036	T5nAagtBG/gUOjePL/vXcw==	2026-01-15 12:50:45.434791
38	l85mibgoajdzbpajvy9x8t3efoxx	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJvdmVybGF5V2l0aCI6eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJvcHRpb25zIjp7ImdyYXZpdHkiOiJzb3V0aGVhc3QifSwia2V5Ijoid2F0ZXJtYXJrL0REV2F0ZXJtYXJrLXYxLnN2ZyJ9L (1).webp	image/webp	{"identified":true,"analyzed":true}	local	136352	PYEFjpZP7oIbq/ptvm4UFw==	2026-01-17 11:05:47.922505
28	4jhb78zxx8aihtt8yz9ujlq5rgxl	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJvdmVybGF5V2l0aCI6eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJvcHRpb25zIjp7ImdyYXZpdHkiOiJzb3V0aHdlc3QifSwia2V5Ijoid2F0ZXJtYXJrL0REV2F0ZXJtYXJrLXYxLnN2ZyJ9LCJyZ.webp	image/webp	{"identified":true,"analyzed":true}	local	139068	8qikZiPwUDHVL1lP55Gu1w==	2026-01-16 15:42:00.802395
39	ahkkx1lto5qyhckc9goq0xu6n1wg	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJvdmVybGF5V2l0aCI6eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJvcHRpb25zIjp7ImdyYXZpdHkiOiJzb3V0aHdlc3QifSwia2V5Ijoid2F0ZXJtYXJrL0REV2F0ZXJtYXJrLXYxLnN2ZyJ9L (1).webp	image/webp	{"identified":true,"analyzed":true}	local	55866	PMxwgt+NBbBABBk7WA3hdA==	2026-01-17 11:05:47.932849
40	qshlu97k4aexm600yhi5qiqjimuo	eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJlZGl0cyI6eyJvdmVybGF5V2l0aCI6eyJidWNrZXQiOiJkb25lZGVhbC5pZS1waG90b3MiLCJvcHRpb25zIjp7ImdyYXZpdHkiOiJzb3V0aGVhc3QifSwia2V5Ijoid2F0ZXJtYXJrL0REV2F0ZXJtYXJrLXYxLnN2ZyJ9LCJyZ.webp	image/webp	{"identified":true,"analyzed":true}	local	106056	Vrz+V7aXMpJEXPTm4+h5XQ==	2026-01-17 11:05:47.940068
\.


--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_attachments (id, name, record_type, record_id, blob_id, created_at) FROM stdin;
2	avatar	User	1	2	2026-01-10 18:14:59.471764
4	images	Listing	1	4	2026-01-15 12:45:14.014843
6	images	Listing	2	6	2026-01-15 12:50:45.412985
7	images	Listing	2	7	2026-01-15 12:50:45.418473
8	images	Listing	2	8	2026-01-15 12:50:45.423027
9	images	Listing	2	9	2026-01-15 12:50:45.427331
10	images	Listing	2	10	2026-01-15 12:50:45.432413
11	images	Listing	2	11	2026-01-15 12:50:45.437127
12	images	Listing	2	12	2026-01-15 12:50:45.44152
28	images	Listing	3	28	2026-01-16 15:42:00.807354
38	images	Listing	3	38	2026-01-17 11:05:47.929263
39	images	Listing	3	39	2026-01-17 11:05:47.936371
40	images	Listing	3	40	2026-01-17 11:05:47.943414
\.


--
-- Data for Name: active_storage_variant_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_storage_variant_records (id, blob_id, variation_digest) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2026-01-09 13:49:40.331485	2026-01-09 13:49:40.331488
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, icon, slug, created_at, updated_at) FROM stdin;
1	Motors	Cars, Vans, Motorcycles	🚗	\N	2026-01-10 13:41:47.558297	2026-01-10 13:41:47.558297
2	Property	Houses, Apartments, Land	🏠	\N	2026-01-10 13:41:47.575899	2026-01-10 13:41:47.575899
3	Jobs	Full-time, Part-time, Contract	💼	\N	2026-01-10 13:41:47.589895	2026-01-10 13:41:47.589895
4	Electronics	Phones, Computers, TVs	📱	\N	2026-01-10 13:41:47.60188	2026-01-10 13:41:47.60188
5	Furniture	Home & Garden	🪑	\N	2026-01-10 13:41:47.613605	2026-01-10 13:41:47.613605
6	Fashion	Clothing & Accessories	👕	\N	2026-01-10 13:41:47.625546	2026-01-10 13:41:47.625546
7	Hobbies	Sports, Games, Books	🎮	\N	2026-01-10 13:41:47.638656	2026-01-10 13:41:47.638656
8	Pets	Dogs, Cats, Birds	🐾	\N	2026-01-10 13:41:47.653978	2026-01-10 13:41:47.653978
9	Services	Babysitting, Car Valeting, Cleaning, etc.	🔧	\N	2026-01-10 13:43:01.837333	2026-01-10 13:43:01.837333
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listings (id, title, description, price, city, created_at, updated_at, category_id, user_id, status, condition, contact_email, contact_phone, views, featured, expires_at, extra_fields) FROM stdin;
1	Volkswagen Polo	2021 Volkswagen Polo grey 	20000.0	Limerick	2026-01-10 14:22:14.836531	2026-01-15 12:46:48.01536	1	2	\N	\N	\N	\N	\N	\N	\N	{"make": "Volkswagen", "year": "2021", "model": "Polo", "mileage": "50000", "fuel_type": "Petrol", "engine_size": "1", "image_order": [4], "subcategory": "Car", "transmission": "Manual", "previous_owners": "0"}
2	!BMW 520D M SPORT PLUS! F10	Well-maintained BMW 520d M Sport Plus, excellent condition, reliable, fully taxed & NCT’d until march 2027 , full factory M Sport, black leather seats, multifuction paddle shift steering wheel , Harmon Kardon sound system ,heated seats, wider nav screen etc\r\n\r\nStunning car. No work needed — really nice car call or text 0873946881 no timewasters genuine buyers only thank you	15750.0	Donegal	2026-01-15 12:50:45.399127	2026-01-15 20:01:12.065107	1	3	\N	\N	\N	\N	\N	\N	\N	{"make": "BMW", "year": "2017", "mileage": "175000", "fuel_type": "Diesel", "engine_size": "2.0L", "image_order": [6, 7, 8, 9, 10, 11, 12], "subcategory": "Car", "transmission": "Automatic", "previous_owners": "4"}
3	VW Passat 2L 150BHP	VW Passat\r\n\r\nRoutinely serviced, timing belt done middle of 2025. Never had a minutes trouble.\r\n\r\nNCT until 07/27\r\n\r\nNew tyres November 2025\r\n\r\n6 speed, cruise control\r\n\r\nOnly selling as need a smaller car due to change of house.\r\n\r\nOpen to negotiations.\r\n\r\nTexts/whatsapp only please.\r\n\r\nCar is in cork city most days	14000.0	Cork	2026-01-15 20:05:43.477877	2026-01-17 11:34:28.299743	1	4	\N	\N	\N	\N	\N	\N	\N	{"make": "Volkswagen", "year": "2017", "mileage": "185000", "fuel_type": "Diesel", "engine_size": "2.0L", "image_order": [28, 38, 39, 40], "subcategory": "Car", "transmission": "Manual", "previous_owners": "0"}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, phone, location, created_at, updated_at, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at) FROM stdin;
2	alexsidorov05@gmail.com	Alex Sidorov	+353852406366	Limerick,Ireland	2026-01-10 13:35:24.93283	2026-01-10 13:35:24.93283	$2a$12$AuzqtaAAC4yWqgrCNhEOI.jyj0dw7zGATvoz2pgm0oirmj305mRQi	\N	\N	\N
1	adrianasecas12@gmail.com	Adriana Secas	+353892126853	Limerick,Ireland	2026-01-09 18:39:24.71751	2026-01-10 18:14:59.740714	$2a$12$Qgx5jypB6UgdUmJTdcjws.5UDjj8E3tw6jz88jAO/vAThvmVbaYWm	\N	\N	\N
3	private@gmail.com	Private Seller	+353873946881	Donegal, Ireland	2026-01-15 12:48:41.278827	2026-01-15 12:48:41.278827	$2a$12$2gXvWrimCbsyaA7IK91VjOjmBZUD3dh21f389eLvyMPV5FfXuJefW	\N	\N	\N
4	ruari@gmail.com	Ruairi 	+353 87 316 6298	Cork, Ireland	2026-01-15 20:03:13.528226	2026-01-15 20:03:13.528226	$2a$12$9V1f.w0QC.2ShyoykD3R.u9yJOPPoT2/mPpW/4X44FPfKh5J44VCG	\N	\N	\N
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorites (id, user_id, listing_id, created_at, updated_at) FROM stdin;
3	2	1	2026-01-10 20:53:33.712891	2026-01-10 20:53:33.712891
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, listing_id, sender_id, recipient_id, content, read, created_at, updated_at) FROM stdin;
1	1	1	2	Hey, is this still for sale?	t	2026-01-10 14:23:29.374433	2026-01-10 14:24:09.736542
3	1	1	2	Is 20000 not too much?	t	2026-01-10 17:49:43.90177	2026-01-10 20:28:56.925749
2	1	1	2	hi	t	2026-01-10 17:42:34.479509	2026-01-10 17:42:34.479509
4	1	2	1	gway ya dope\n	f	2026-01-10 20:44:06.622603	2026-01-10 20:44:06.622603
5	1	2	1	Hey	f	2026-01-15 12:41:29.505375	2026-01-15 12:41:29.505375
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, reviewer_id, reviewed_user_id, rating, comment, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20260109134933
20260109135555
20260109174930
20260109174947
20260109175030
20260109175048
20260109175243
20260109180900
20260109180908
20260109190000
20260110140000
20250115000000
20260113163247
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, created_at, updated_at) FROM stdin;
\.


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_storage_attachments_id_seq', 40, true);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_storage_blobs_id_seq', 40, true);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_storage_variant_records_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 9, true);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorites_id_seq', 3, true);


--
-- Name: listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listings_id_seq', 3, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 5, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- PostgreSQL database dump complete
--

\unrestrict NLo8gEBOv4kg8xLJOQPUEQXy0WNswlKssaOqkNeqsgGOEat7ZbG7ruQDmqQqRvf

